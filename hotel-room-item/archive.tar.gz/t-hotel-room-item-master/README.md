#t-hotel-room-item
